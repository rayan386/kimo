export default function Home() {
  return (
    <div className="text-center text-orange-500 font-bold text-3xl mt-10">
      Bienvenue sur KIMO 🎉
    </div>
  );
}